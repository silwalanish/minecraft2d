﻿Congratulations, you have successfully downloaded font file! 

This font is provided to you by Fonts2u.com – the largest online 
repository of free fonts for Windows and Mac.



How to install this font on your computer?

For Windows 7 / Vista users:

- Right-click the font file(s) and choose "Install".

For users of the previous Windows versions:

- Copy the included file(s) into a default Windows font folder 
  (usually C:\WINDOWS\FONTS or C:\WINNT\FONTS)

For Mac users:

Mac OS X 10.3 or above (including the FontBook)

- Double-click the font file and hit "Install font" button at 
  the bottom of the preview.

Mac OS X

- Either copy the font file(s) to /Library/Fonts (for all users), 
  or to /Users/Your_username/Library/Fonts (for you only).

Mac OS 9 or earlier

- You have to convert the font file(s) you have downloaded. 
  Drag the font suitcases into the System folder. The system 
  will propose you to add them to the Fonts folder.

For Linux users:

- Copy the font file(s) to /USR/SHARE/FONTS

